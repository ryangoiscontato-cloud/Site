'use client'

import { useState, useRef, useEffect } from 'react'
import type { Produto } from '@/lib/types'

interface Props {
  produtos: Produto[]
  value: string
  onChange: (id: string) => void
  hasError?: boolean
}

export default function ProductSearchSelect({ produtos, value, onChange, hasError }: Props) {
  const [query, setQuery]   = useState('')
  const inputRef            = useRef<HTMLInputElement>(null)

  const selected = produtos.find(p => p.id === value)

  const results = query.trim()
    ? produtos.filter(p =>
        p.nome.toLowerCase().includes(query.toLowerCase()) ||
        p.codigo.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 8)
    : []

  function pick(p: Produto) {
    onChange(p.id)
    setQuery('')
  }

  function clear() {
    onChange('')
    setQuery('')
    setTimeout(() => inputRef.current?.focus(), 0)
  }

  // Close list on outside click
  const wrapRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    function handle(e: MouseEvent) {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) setQuery('')
    }
    document.addEventListener('mousedown', handle)
    return () => document.removeEventListener('mousedown', handle)
  }, [])

  if (selected) {
    return (
      <div className={`flex items-center gap-2 px-3 py-2 border rounded-lg bg-blue-50 ${hasError ? 'border-red-400' : 'border-blue-300'}`}>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-blue-900 truncate">{selected.nome}</p>
          <p className="text-xs text-blue-500">{selected.codigo} · {selected.unidade}</p>
        </div>
        <button
          type="button"
          onClick={clear}
          className="flex-shrink-0 w-6 h-6 flex items-center justify-center rounded-full bg-blue-200 hover:bg-blue-300 text-blue-700 text-xs font-bold transition-colors"
          title="Alterar produto"
        >
          ×
        </button>
      </div>
    )
  }

  return (
    <div ref={wrapRef} className="relative">
      <input
        ref={inputRef}
        type="text"
        value={query}
        onChange={e => setQuery(e.target.value)}
        placeholder="Digite o nome ou código do produto..."
        className={`form-field ${hasError ? 'border-red-400 ring-2 ring-red-100' : ''}`}
      />
      {query.trim() === '' && (
        <p className="text-xs text-gray-400 mt-1.5 pl-1">Digite para buscar um produto</p>
      )}
      {query.trim() !== '' && results.length === 0 && (
        <p className="text-xs text-gray-400 mt-1.5 pl-1">Nenhum produto encontrado</p>
      )}
      {results.length > 0 && (
        <ul className="mt-1.5 border border-gray-200 rounded-lg bg-white shadow-md divide-y divide-gray-100 max-h-52 overflow-y-auto">
          {results.map(p => (
            <li key={p.id}>
              <button
                type="button"
                onClick={() => pick(p)}
                className="w-full text-left px-3 py-2.5 hover:bg-blue-50 transition-colors"
              >
                <p className="text-sm font-semibold text-gray-800">{p.nome}</p>
                <p className="text-xs text-gray-400">{p.codigo} · saldo: {p.saldo} {p.unidade}</p>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
